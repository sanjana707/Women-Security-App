package com.example.login_database_try;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {
    FirebaseAuth mAuth;
    EditText edit_email;
    EditText edit_password;
    Button btn_login;
    Button btn_register;
    String pattern = "^[a-zA-Z0-9+_.-]+@[a-z]+\\.[a-z]+";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        edit_email = findViewById(R.id.edit_email);
        edit_password = findViewById(R.id.edit_password);
        btn_login = findViewById(R.id.btn_login);
        btn_register = findViewById(R.id.btn_register);

        mAuth = FirebaseAuth.getInstance();

        btn_login.setOnClickListener(view->{
            loginUser();
        });

        btn_register.setOnClickListener(view->{
            Intent i = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(i);
        });
    }

    private void loginUser() {
        String email = edit_email.getText().toString();
        String password = edit_password.getText().toString();

        if(email.isEmpty())
        {
            edit_email.setError("Email cannot be empty");
            edit_email.requestFocus();
        }
        else if(password.isEmpty())
        {
            edit_password.setError("Password cannot be empty");
            edit_password.requestFocus();
        }
        else if(!email.matches(pattern))
        {
            edit_email.setError("Invalid email");
            edit_email.requestFocus();
        }
        else if(password.length() < 8)
        {
            edit_password.setError("Password cannot be less than 8 characters");
            edit_password.requestFocus();
        }
        else
        {
            mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful())
                    {
                        Toast.makeText(LoginActivity.this, "User logged in successfully", Toast.LENGTH_SHORT).show();

                        Intent i_main = new Intent(LoginActivity.this, StoreContactsActivity.class);
                        startActivity(i_main);
                        LoginActivity.this.finish();
                    }
                    else
                    {
                        Toast.makeText(LoginActivity.this, "Login error"+ task.getException(), Toast.LENGTH_LONG).show();
                    }
                }
            });
        }
    }
}
