package com.example.login_database_try;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class Emergency extends AppCompatActivity {
    ImageButton imagebutton1,imagebutton2,imagebutton3,imagebutton4,imagebutton5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emergency);
        imagebutton1=findViewById(R.id.button8);
        imagebutton2=findViewById(R.id.button9);
        imagebutton3=findViewById(R.id.button10);
        imagebutton4=findViewById(R.id.button11);
        imagebutton5=findViewById(R.id.button12);

        imagebutton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call=new Intent(Intent.ACTION_DIAL);
                call.setData(Uri.parse("tel:+102"));
                startActivity(call);
            }
        });


        imagebutton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call1=new Intent(Intent.ACTION_DIAL);
                call1.setData(Uri.parse("tel:+1091"));
                startActivity(call1);
            }
        });

        imagebutton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call2=new Intent(Intent.ACTION_DIAL);
                call2.setData(Uri.parse("tel:+01126942369"));
                startActivity(call2);
            }
        });


        imagebutton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call3=new Intent(Intent.ACTION_DIAL);
                call3.setData(Uri.parse("tel:+112"));
                startActivity(call3);
            }
        });

        imagebutton5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent call4=new Intent(Intent.ACTION_DIAL);
                call4.setData(Uri.parse("tel:+100"));
                startActivity(call4);
            }
        });


    }
}
