package com.example.login_database_try;

public class LoginActivity {
}
