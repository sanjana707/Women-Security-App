package com.example.login_database_try;

public class Safty_tips {
}
